$(document).ready(function() {
    $('.navbar-nav .nav-link').on('click', function() {
      if ($('.navbar-toggler').is(':visible')) {
        $('.navbar-collapse').collapse('hide');
      }
    });
  });